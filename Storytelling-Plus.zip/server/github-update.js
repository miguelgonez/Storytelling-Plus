import { Octokit } from '@octokit/rest';
import fs from 'fs';
import path from 'path';

let connectionSettings = null;

async function getAccessToken() {
  if (connectionSettings && connectionSettings.settings.expires_at && new Date(connectionSettings.settings.expires_at).getTime() > Date.now()) {
    return connectionSettings.settings.access_token;
  }
  
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY 
    ? 'repl ' + process.env.REPL_IDENTITY 
    : process.env.WEB_REPL_RENEWAL 
    ? 'depl ' + process.env.WEB_REPL_RENEWAL 
    : null;

  if (!xReplitToken) throw new Error('Token not found');

  connectionSettings = await fetch(
    'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=github',
    { headers: { 'Accept': 'application/json', 'X_REPLIT_TOKEN': xReplitToken } }
  ).then(res => res.json()).then(data => data.items?.[0]);

  return connectionSettings?.settings?.access_token || connectionSettings.settings?.oauth?.credentials?.access_token;
}

async function getClient() {
  return new Octokit({ auth: await getAccessToken() });
}

const IGNORE = ['node_modules', '.git', 'dist', '.cache', '.replit', 'replit.nix', '.upm', '.config', 
  'package-lock.json', 'github-update.js', '.DS_Store'];

function shouldIgnore(p) { return IGNORE.some(i => p.includes(i)); }

function getAllFiles(dir, baseDir = dir) {
  const files = [];
  for (const item of fs.readdirSync(dir)) {
    const fullPath = path.join(dir, item);
    const relativePath = path.relative(baseDir, fullPath);
    if (shouldIgnore(relativePath)) continue;
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) files.push(...getAllFiles(fullPath, baseDir));
    else files.push({ path: relativePath, fullPath });
  }
  return files;
}

async function updateGitHub() {
  const octokit = await getClient();
  const { data: user } = await octokit.users.getAuthenticated();
  const owner = user.login;
  const repo = 'Storytelling-Plus';
  
  console.log(`Actualizando: https://github.com/${owner}/${repo}\n`);
  
  const projectDir = process.cwd();
  const files = getAllFiles(projectDir);
  console.log(`Subiendo ${files.length} archivos...\n`);
  
  let ref;
  try {
    ref = await octokit.git.getRef({ owner, repo, ref: 'heads/main' });
  } catch (e) {
    ref = await octokit.git.getRef({ owner, repo, ref: 'heads/master' });
  }
  const baseSha = ref.data.object.sha;
  const baseCommit = await octokit.git.getCommit({ owner, repo, commit_sha: baseSha });
  
  const blobs = [];
  for (const file of files) {
    const content = fs.readFileSync(file.fullPath);
    console.log(`Blob: ${file.path}`);
    const blob = await octokit.git.createBlob({
      owner, repo,
      content: content.toString('base64'),
      encoding: 'base64'
    });
    blobs.push({ path: file.path, mode: '100644', type: 'blob', sha: blob.data.sha });
  }
  
  console.log('\nCreando árbol...');
  const tree = await octokit.git.createTree({
    owner, repo,
    base_tree: baseCommit.data.tree.sha,
    tree: blobs
  });
  
  console.log('Creando commit...');
  const commit = await octokit.git.createCommit({
    owner, repo,
    message: 'fix: Add favicon and update ZIP package\n\n- Added favicon using NextHealth logo\n- Resolved 404 error for favicon.ico\n- Updated Storytelling-Plus.zip with latest changes',
    tree: tree.data.sha,
    parents: [baseSha]
  });
  
  console.log('Actualizando rama...');
  await octokit.git.updateRef({
    owner, repo,
    ref: `heads/${ref.data.ref.split('/').pop()}`,
    sha: commit.data.sha
  });
  
  console.log('\n========================================');
  console.log('CAMBIOS SUBIDOS EXITOSAMENTE!');
  console.log(`URL: https://github.com/${owner}/${repo}`);
  console.log('========================================');
}

updateGitHub().catch(e => {
  console.error('Error:', e.message);
  if (e.response) console.error(e.response.data);
  process.exit(1);
});
