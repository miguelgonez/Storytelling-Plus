import React, { useEffect, useState } from 'react';
import { TemplateConfig } from '../types';
import { DEFAULT_TEMPLATE } from '../constants';

interface TemplateManagerProps {
  isOpen: boolean;
  onClose: () => void;
  templates: TemplateConfig[];
  activeTemplate: TemplateConfig;
  onSave: (template: TemplateConfig) => void;
  onSelect: (template: TemplateConfig) => void;
  onDelete: (name: string) => void;
}

const emptyTemplate: TemplateConfig = {
  name: '',
  protagonistas: '',
  tono: '',
  rangoPaginas: { min: 8, max: 8 },
  apariencia: '',
  idioma: 'español',
};

export const TemplateManager: React.FC<TemplateManagerProps> = ({
  isOpen,
  onClose,
  templates,
  activeTemplate,
  onSave,
  onSelect,
  onDelete,
}) => {
  const [form, setForm] = useState<TemplateConfig>(activeTemplate ?? emptyTemplate);

  useEffect(() => {
    setForm(activeTemplate ?? emptyTemplate);
  }, [activeTemplate, isOpen]);

  if (!isOpen) return null;

  const updateField = <K extends keyof TemplateConfig>(key: K, value: TemplateConfig[K]) => {
    setForm(prev => ({ ...prev, [key]: value }));
  };

  const updateRange = (key: 'min' | 'max', value: number) => {
    setForm(prev => ({
      ...prev,
      rangoPaginas: { ...prev.rangoPaginas, [key]: value },
    }));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const min = Math.min(form.rangoPaginas.min, form.rangoPaginas.max);
    const max = Math.max(form.rangoPaginas.min, form.rangoPaginas.max);
    onSave({
      ...form,
      name: form.name.trim(),
      rangoPaginas: { min, max },
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-40 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-5xl w-full overflow-hidden border-4 border-blue-200">
        <div className="flex justify-between items-center px-6 py-4 border-b border-blue-100">
          <div>
            <p className="text-xs uppercase font-bold text-blue-500 tracking-wide">Plantillas</p>
            <h2 className="text-2xl font-bold text-slate-900">Personaliza los prompts y la apariencia</h2>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-full bg-slate-100 text-slate-700 font-semibold hover:bg-slate-200"
          >
            Cerrar
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 p-6">
          <div className="lg:col-span-2 space-y-4">
            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <label className="flex flex-col text-sm font-semibold text-slate-700">
                  Nombre de la plantilla
                  <input
                    className="mt-1 rounded-lg border border-slate-200 px-3 py-2 focus:ring-2 focus:ring-blue-400"
                    value={form.name}
                    onChange={e => updateField('name', e.target.value)}
                    placeholder="Ej. Pediatría colorida"
                    required
                  />
                </label>
                <label className="flex flex-col text-sm font-semibold text-slate-700">
                  Idioma
                  <input
                    className="mt-1 rounded-lg border border-slate-200 px-3 py-2 focus:ring-2 focus:ring-blue-400"
                    value={form.idioma}
                    onChange={e => updateField('idioma', e.target.value)}
                    placeholder="español"
                  />
                </label>
              </div>

              <label className="flex flex-col text-sm font-semibold text-slate-700">
                Protagonistas
                <input
                  className="mt-1 rounded-lg border border-slate-200 px-3 py-2 focus:ring-2 focus:ring-blue-400"
                  value={form.protagonistas}
                  onChange={e => updateField('protagonistas', e.target.value)}
                  placeholder="Ana (doctora) y Alex (paciente curioso)"
                />
              </label>

              <label className="flex flex-col text-sm font-semibold text-slate-700">
                Tono
                <input
                  className="mt-1 rounded-lg border border-slate-200 px-3 py-2 focus:ring-2 focus:ring-blue-400"
                  value={form.tono}
                  onChange={e => updateField('tono', e.target.value)}
                  placeholder="empático, didáctico, visual"
                />
              </label>

              <label className="flex flex-col text-sm font-semibold text-slate-700">
                Apariencia visual
                <textarea
                  className="mt-1 rounded-lg border border-slate-200 px-3 py-2 focus:ring-2 focus:ring-blue-400"
                  value={form.apariencia}
                  onChange={e => updateField('apariencia', e.target.value)}
                  placeholder="estilo infografía moderna, colores claros, línea limpia"
                  rows={2}
                />
              </label>

              <div className="grid grid-cols-2 gap-4">
                <label className="flex flex-col text-sm font-semibold text-slate-700">
                  Páginas mínimas
                  <input
                    type="number"
                    min={1}
                    className="mt-1 rounded-lg border border-slate-200 px-3 py-2 focus:ring-2 focus:ring-blue-400"
                    value={form.rangoPaginas.min}
                    onChange={e => updateRange('min', Number(e.target.value))}
                  />
                </label>
                <label className="flex flex-col text-sm font-semibold text-slate-700">
                  Páginas máximas
                  <input
                    type="number"
                    min={1}
                    className="mt-1 rounded-lg border border-slate-200 px-3 py-2 focus:ring-2 focus:ring-blue-400"
                    value={form.rangoPaginas.max}
                    onChange={e => updateRange('max', Number(e.target.value))}
                  />
                </label>
              </div>

              <div className="flex flex-wrap gap-3">
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 text-white rounded-full font-semibold hover:bg-blue-500"
                >
                  Guardar plantilla
                </button>
                <button
                  type="button"
                  onClick={() => setForm(DEFAULT_TEMPLATE)}
                  className="px-5 py-2 bg-slate-100 text-slate-800 rounded-full font-semibold hover:bg-slate-200"
                >
                  Usar plantilla base
                </button>
                <button
                  type="button"
                  onClick={() => setForm(emptyTemplate)}
                  className="px-5 py-2 bg-white border border-slate-200 text-slate-600 rounded-full font-semibold hover:bg-slate-50"
                >
                  Limpiar campos
                </button>
              </div>
            </form>
          </div>

          <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-800">Tus plantillas</h3>
              <span className="text-xs font-semibold text-slate-500">
                {templates.length || '0'} guardadas
              </span>
            </div>

            <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
              {[activeTemplate, ...templates.filter(t => t.name !== activeTemplate.name)].map(t => (
                <div
                  key={t.name || 'active'}
                  className={`p-3 rounded-xl border flex items-center justify-between ${
                    t.name === activeTemplate.name ? 'border-blue-400 bg-blue-50' : 'border-slate-200'
                  }`}
                >
                  <div>
                    <p className="font-bold text-slate-800">{t.name || 'Sin nombre'}</p>
                    <p className="text-xs text-slate-500">
                      {t.protagonistas} · {t.rangoPaginas.min}-{t.rangoPaginas.max} páginas
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      className="px-3 py-1 text-sm rounded-full bg-blue-600 text-white hover:bg-blue-500"
                      onClick={() => onSelect(t)}
                    >
                      Activar
                    </button>
                    <button
                      className="px-3 py-1 text-sm rounded-full bg-slate-100 text-slate-700 hover:bg-slate-200"
                      onClick={() => setForm(t)}
                    >
                      Editar
                    </button>
                    {t.name && (
                      <button
                        className="px-3 py-1 text-sm rounded-full bg-red-50 text-red-600 hover:bg-red-100"
                        onClick={() => onDelete(t.name)}
                      >
                        Borrar
                      </button>
                    )}
                  </div>
                </div>
              ))}
              {templates.length === 0 && (
                <p className="text-sm text-slate-500">No hay plantillas guardadas aún.</p>
              )}
            </div>

            <div className="text-xs text-slate-500 leading-relaxed">
              <p>Las plantillas se guardan en tu navegador para reutilizarlas rápido.</p>
              <p>Usa nombres únicos para que sea fácil identificarlas.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
