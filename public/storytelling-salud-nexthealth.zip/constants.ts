import { TemplateConfig, PromptSet } from './types';

// Models
export const TEXT_MODEL = 'gemini-3-pro-preview';
export const IMAGE_MODEL = 'gemini-3-pro-image-preview';

// Plantilla por defecto
export const DEFAULT_TEMPLATE: TemplateConfig = {
  name: 'NextHealth Storytelling',
  protagonistas: 'Ana, una experta en salud, y Alex, un paciente curioso',
  tono: 'informativo, empático y visualmente atractivo',
  rangoPaginas: { min: 8, max: 8 },
  apariencia: 'estilo de infografía moderna, con colores calmados y claros',
  idioma: 'español',
};

export const buildPromptsFromTemplate = (template: TemplateConfig): PromptSet => {
  const { min, max } = template.rangoPaginas;
  const pagesText = min === max
    ? `exactamente ${min} páginas`
    : `entre ${min} y ${max} páginas`;

  return {
    analysisPrompt: `Usa a ${template.protagonistas} como protagonistas; resume en ${template.idioma} con tono ${template.tono} el contenido central del PDF de forma clara y didáctica.`,
    planningPrompt: `Con base en el resumen anterior, diseña un cómic educativo de ${pagesText} donde ${template.protagonistas} guían al lector. Devuelve la lista con narrativa breve y sugerencia visual para cada página.`,
    imagePrefix: `Genera una página de cómic educativa en ${template.idioma} usando Nexthealth Storytelling, con ${template.protagonistas} como protagonistas. Apariencia: ${template.apariencia}.`,
    idioma: template.idioma,
  };
};
