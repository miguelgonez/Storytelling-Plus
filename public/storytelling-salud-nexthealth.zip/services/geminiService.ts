import { GoogleGenAI, Type, Schema } from "@google/genai";
import { PagePlan, StoryPage, PromptSet } from "../types";
import { TEXT_MODEL, IMAGE_MODEL } from "../constants";

const getAIClient = () => {
  if (!process.env.API_KEY) {
    throw new Error("API Key not found in environment variables");
  }
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

/**
 * Step 1: Analyze the paper and get the main idea.
 */
export const analyzePaper = async (
  fileBase64: string,
  mimeType: string,
  prompts: PromptSet
): Promise<string> => {
  const ai = getAIClient();
  
  try {
    const response = await ai.models.generateContent({
      model: TEXT_MODEL,
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType,
              data: fileBase64
            }
          },
          { text: prompts.analysisPrompt }
        ]
      }
    });

    return response.text || "Failed to generate analysis.";
  } catch (error) {
    console.error("Analysis Error:", error);
    throw new Error("Failed to analyze the paper.");
  }
};

/**
 * Step 2: Plan the storybook pages.
 */
export const planStory = async (analysisContext: string, prompts: PromptSet): Promise<PagePlan[]> => {
  const ai = getAIClient();

  // Extract text regardless of SDK shape (method vs property)
  const extractText = (response: any): string => {
    if (!response) return "";
    if (typeof response.text === "function") return response.text();
    if (typeof response.text === "string") return response.text;
    const parts = response.candidates?.[0]?.content?.parts ?? [];
    const texts = parts
      .map((p: any) => (p.text ? p.text : ""))
      .filter(Boolean);
    return texts.join("\n");
  };

  const parsePlan = (raw: string): PagePlan[] => {
    const clean = raw.trim();
    const fenced = clean.match(/```(?:json)?\s*([\s\S]*?)```/i);
    const candidate = fenced ? fenced[1] : clean;
    const start = candidate.indexOf("[");
    const end = candidate.lastIndexOf("]");
    if (start !== -1 && end !== -1 && end > start) {
      return JSON.parse(candidate.slice(start, end + 1)) as PagePlan[];
    }
    return JSON.parse(candidate) as PagePlan[];
  };

  const schema: Schema = {
    type: Type.ARRAY,
    items: {
      type: Type.OBJECT,
      properties: {
        pageNumber: { type: Type.INTEGER },
        description: { type: Type.STRING, description: "The narrative content of this page" },
        visualCue: { type: Type.STRING, description: "Description of the visual scene for the image generator" }
      },
      required: ["pageNumber", "description", "visualCue"]
    }
  };

  try {
    const response = await ai.models.generateContent({
      model: TEXT_MODEL,
      contents: {
        parts: [
          { text: `Context: ${analysisContext}` },
          { text: prompts.planningPrompt }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
      }
    });

    const text = extractText(response);
    if (!text) throw new Error("No plan generated");

    try {
      const parsed = parsePlan(text);
      if (!Array.isArray(parsed) || parsed.length === 0) {
        throw new Error("Empty plan received");
      }
      return parsed;
    } catch (parseErr: any) {
      console.error("Planning parse error", parseErr, text);
      throw new Error("No se pudo leer el plan devuelto por Gemini. Intenta de nuevo o ajusta el PDF.");
    }
  } catch (error) {
    console.error("Planning Error:", error);
    const message = (error as any)?.message || "Failed to plan the storytelling structure.";
    throw new Error(message);
  }
};

/**
 * Step 3: Generate a single page image.
 */
export const generateStoryPage = async (
  context: string,
  pagePlan: PagePlan,
  prompts: PromptSet
): Promise<StoryPage> => {
  const ai = getAIClient();
  
  const prompt = `${prompts.imagePrefix}. Página ${pagePlan.pageNumber} (relación 2:3 en vertical, idioma ${prompts.idioma}).
  
  Contexto: ${context}
  
  Descripción de la página: ${pagePlan.description}
  Escena visual: ${pagePlan.visualCue}`;

  try {
    const response = await ai.models.generateContent({
      model: IMAGE_MODEL,
      contents: {
        parts: [{ text: prompt }]
      },
      config: {
        imageConfig: {
            aspectRatio: "3:4", 
        }
      }
    });

    let imageUrl = '';
    
    // Iterate through parts to find the image
    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          imageUrl = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
          break; 
        }
      }
    }

    if (!imageUrl) {
        throw new Error(`No image generated for page ${pagePlan.pageNumber}`);
    }

    return {
      pageNumber: pagePlan.pageNumber,
      imageUrl: imageUrl,
      description: pagePlan.description
    };

  } catch (error) {
    console.error(`Image Generation Error (Page ${pagePlan.pageNumber}):`, error);
    throw error;
  }
};
