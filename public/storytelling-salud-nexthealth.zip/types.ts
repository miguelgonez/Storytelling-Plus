export interface PagePlan {
  pageNumber: number;
  description: string;
  visualCue: string;
}

export interface StoryPage {
  pageNumber: number;
  imageUrl: string;
  description: string;
}

export enum AppStatus {
  IDLE = 'IDLE',
  ANALYZING = 'ANALYZING',
  PLANNING = 'PLANNING',
  GENERATING_IMAGES = 'GENERATING_IMAGES',
  COMPLETE = 'COMPLETE',
  ERROR = 'ERROR',
}

export interface ProcessingState {
  status: AppStatus;
  currentStepDescription?: string;
  progress: number; // 0 to 100
  totalSteps: number;
  currentStep: number;
  error?: string;
}

export interface TemplateConfig {
  name: string;
  protagonistas: string;
  tono: string;
  rangoPaginas: {
    min: number;
    max: number;
  };
  apariencia: string;
  idioma: string;
}

export interface PromptSet {
  analysisPrompt: string;
  planningPrompt: string;
  imagePrefix: string;
  idioma: string;
}
